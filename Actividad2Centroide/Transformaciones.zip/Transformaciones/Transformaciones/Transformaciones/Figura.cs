﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Transformaciones
{
    
    internal class Figura
    {
        public PointF centroide;
        public List<PointF> puntos;
        
        public Figura() 
        {
            puntos = new List<PointF>();
        }

        public void updateCentroid()
        {
            centroide = new PointF(0, 0);
            for (int p = 0; p < puntos.Count; p++)
            {
                centroide.X += puntos[p].X;
                centroide.Y += puntos[p].Y;
            }
            centroide.X = centroide.X / puntos.Count;
            centroide.Y = centroide.Y / puntos.Count;
        }

        public PointF TranslateToCenter(PointF a, Size size)
        {
            int Sx = (int)(size.Width / 2);
            int Sy = (int)(size.Height / 2);

            return (new PointF(a.X + Sx,Sy + a.Y));
        }
        public PointF Translate(PointF a, PointF b)
        {
            return (new PointF(a.X+b.X,a.Y+b.Y));
        }

        public PointF Rotate(PointF a, double angle, PointF center)
        {
            PointF b = new PointF();

            b.X = (float)((a.X - center.X) * Math.Cos(angle) - (a.Y - center.Y) * Math.Sin(angle) + center.X);
            b.Y = (float)((a.X - center.X) * Math.Sin(angle) + (a.Y - center.Y) * Math.Cos(angle) + center.Y);

            return b;
        }

        public void rotateFigure(String angleText)
        {
            double angle = Double.Parse(angleText) * Math.PI / 180;
            for (int p = 0; p < puntos.Count; p++)
            {
                puntos[p] = Rotate(puntos[p], angle, centroide);
            }
        }



    }
}
