﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Transformaciones
{
    
    internal class Figura
    {
        public PointF centroide;
        //lista de puntos originales que son los que son transformados
        public List<PointF> puntos;
        //las siguientes listas sirven para que una vez que se haga x transformacion los datos se queden
        //tal cual hasta que se haga una transformacion del mismo tipo
        public List<PointF> scaledPoints;
        public List<PointF> translatedPoints;
        public List<PointF> transformedPoints;
        
        public Figura() 
        {
            puntos = new List<PointF>();
            scaledPoints = new List<PointF>();
            translatedPoints = new List<PointF>();
            transformedPoints = new List<PointF>();
        }

        public void addPoint(PointF point) 
        { 
            //en esta funcion va a permitir crear cualquier tipo de figura solo indicando los puntos
            //luego se puede escalar a que los puntos provengan de las coordenadas del picture box con un click
            puntos.Add(point);
            scaledPoints.Add(point);
            translatedPoints.Add(point);
            transformedPoints.Add(point);
            getCentroid();
        }

        public void renderFigure(Graphics g) 
        {
            //une los puntos adyacentes conforme se fueron agregando
            for (int p = 0; p < puntos.Count-1; p++)
            {
                g.DrawLine(Pens.Yellow, transformedPoints[p], transformedPoints[p+1]);
            }
            g.DrawLine(Pens.Yellow, transformedPoints[puntos.Count-1], transformedPoints[0]);
        }

        private void getCentroid()
        {
            //promedio de puntos = centroide
            centroide = new PointF(0, 0);
            for (int p = 0; p < puntos.Count; p++)
            {
                centroide.X += scaledPoints[p].X;
                centroide.Y += scaledPoints[p].Y;
            }
            centroide.X = centroide.X / puntos.Count;
            centroide.Y = centroide.Y / puntos.Count;
        }
        private void updateCentroid()
        {
            centroide = new PointF(0, 0);
            for (int p = 0; p < puntos.Count; p++)
            {
                centroide.X += scaledPoints[p].X;
                centroide.Y += scaledPoints[p].Y;
                //si en lugar de usar scaledPoints usas transformed sale algo bien curioso jajaj
            }
            centroide.X = centroide.X / puntos.Count;
            centroide.Y = centroide.Y / puntos.Count;
        }

        private PointF TranslateToCenter(PointF a, Size size)
        {
            int Sx = (int)(size.Width / 2);
            int Sy = (int)(size.Height / 2);

            return (new PointF(a.X + Sx,Sy + a.Y));
        }
        //esto dependiendo de cuanto arrastres los vertices va a ser el punto b en el proyecto
        private PointF Translate(PointF a, PointF b)
        {
            return (new PointF(a.X+b.X,a.Y+b.Y));
        }

        //rotar con respecto al pivote
        private PointF Rotate(PointF a, double angle, PointF center)
        {
            PointF b = new PointF();

            b.X = (float)((a.X - center.X) * Math.Cos(angle) - (a.Y - center.Y) * Math.Sin(angle) + center.X);
            b.Y = (float)((a.X - center.X) * Math.Sin(angle) + (a.Y - center.Y) * Math.Cos(angle) + center.Y);

            return b;
        }

        public void translate_0_0() 
        {
            for (int p = 0; p < puntos.Count; p++)
            {
                transformedPoints[p] = translatedPoints[p];
            }
        }

        public void translateFigureFourthQuadrant(Size size)
        {
            for (int p = 0; p < puntos.Count; p++)
            {
                transformedPoints[p] = TranslateToCenter(translatedPoints[p], size);
            }
        }
        public void translateFigureCenter(Size size)
        {
            translateFigureFourthQuadrant(size);
            for (int p = 0; p < puntos.Count; p++)
            {
                transformedPoints[p] = Translate(transformedPoints[p], new PointF(-50,-50));
            }
        }

        public void rotateFigure(String angleText)
        {
            try {
                double angle = Double.Parse(angleText) * Math.PI / 180;
                for (int p = 0; p < puntos.Count; p++)
                {
                    translatedPoints[p] = Rotate(scaledPoints[p], angle, centroide);
                }
            }
            catch (Exception e)
            {
                double angle = 0;
                for (int p = 0; p < puntos.Count; p++)
                {
                    translatedPoints[p] = Rotate(scaledPoints[p], angle, centroide);
                }
            }     
        }

        //escalar con respecto a las dimensiones deseadas, luego habra que hacer una funcion que lo haga punto por punto
        //dependiendo de cuanto arrastres el punto haces la resta y listo esa es la scale quantity
        public void scaleFigure(int scaleQuantity)
        {
            for (int p = 1; p < puntos.Count; p++) 
            {
                scaledPoints[p] = new PointF(puntos[p].X*scaleQuantity, puntos[p].Y*scaleQuantity); ; 
            }
            updateCentroid();
        }


    }
}
