﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Transformaciones
{
    internal class Canvas
    {
        Bitmap bmp;
        Graphics g;

        public Canvas(PictureBox pictureBox)
        {
            bmp = new Bitmap(pictureBox.Width, pictureBox.Height);
            g = Graphics.FromImage(bmp);
            pictureBox.Image = bmp;
        }

        public void RenderSquare(Cuadrado cuadrado, Size size)
        {
            g.Clear(Color.Black);
            Point e = new Point(size.Width / 2, size.Height);
            Point f = new Point(size.Width / 2, 0);
            Point h = new Point(0, size.Height / 2);
            Point i = new Point(size.Width, size.Height / 2);
            g.DrawLine(Pens.Gray, e, f);
            g.DrawLine(Pens.Gray, i, h);

            g.DrawLine(Pens.Yellow, cuadrado.puntos[0], cuadrado.puntos[1]);
            g.DrawLine(Pens.Yellow, cuadrado.puntos[1], cuadrado.puntos[2]);
            g.DrawLine(Pens.Yellow, cuadrado.puntos[2], cuadrado.puntos[3]);
            g.DrawLine(Pens.Yellow, cuadrado.puntos[3], cuadrado.puntos[0]);
            
        }

        public void RenderTriangle(Triangulo triangulo, Size size)
        {
            g.Clear(Color.Black);
            Point e = new Point(size.Width / 2, size.Height);
            Point f = new Point(size.Width / 2, 0);
            Point h = new Point(0, size.Height / 2);
            Point i = new Point(size.Width, size.Height / 2);

            g.DrawLine(Pens.Gray, e, f);
            g.DrawLine(Pens.Gray, i, h);

            g.DrawLine(Pens.Yellow, triangulo.puntos[0], triangulo.puntos[1]);
            g.DrawLine(Pens.Yellow, triangulo.puntos[1], triangulo.puntos[2]);
            g.DrawLine(Pens.Yellow, triangulo.puntos[2], triangulo.puntos[0]);
        }
    }
}
