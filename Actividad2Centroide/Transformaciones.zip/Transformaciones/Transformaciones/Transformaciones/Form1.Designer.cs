﻿namespace Transformaciones
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button5 = new Button();
            button6 = new Button();
            angleTextBox = new TextBox();
            angleLabel = new Label();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Black;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(12, 44);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(776, 312);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button1
            // 
            button1.Location = new Point(41, 362);
            button1.Name = "button1";
            button1.Size = new Size(172, 29);
            button1.TabIndex = 1;
            button1.Text = "Traslation 0,0";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(41, 397);
            button2.Name = "button2";
            button2.Size = new Size(172, 29);
            button2.TabIndex = 2;
            button2.Text = "Traslation 4th cuadrant";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(240, 362);
            button3.Name = "button3";
            button3.Size = new Size(137, 29);
            button3.TabIndex = 3;
            button3.Text = "Traslation center";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button5
            // 
            button5.Location = new Point(240, 397);
            button5.Name = "button5";
            button5.Size = new Size(137, 29);
            button5.TabIndex = 5;
            button5.Text = "Rotate";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(404, 362);
            button6.Name = "button6";
            button6.Size = new Size(137, 29);
            button6.TabIndex = 6;
            button6.Text = "Scale";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // angleTextBox
            // 
            angleTextBox.Location = new Point(64, 11);
            angleTextBox.Name = "angleTextBox";
            angleTextBox.Size = new Size(80, 27);
            angleTextBox.TabIndex = 7;
            angleTextBox.Text = "0";
            // 
            // angleLabel
            // 
            angleLabel.AutoSize = true;
            angleLabel.ForeColor = Color.White;
            angleLabel.Location = new Point(8, 14);
            angleLabel.Name = "angleLabel";
            angleLabel.Size = new Size(51, 20);
            angleLabel.TabIndex = 8;
            angleLabel.Text = "Angle:";
            // 
            // button4
            // 
            button4.BackColor = Color.Red;
            button4.ForeColor = Color.White;
            button4.Location = new Point(404, 397);
            button4.Name = "button4";
            button4.Size = new Size(137, 29);
            button4.TabIndex = 9;
            button4.Text = "Change figure";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.WindowText;
            ClientSize = new Size(800, 450);
            Controls.Add(button4);
            Controls.Add(angleLabel);
            Controls.Add(angleTextBox);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button5;
        private Button button6;
        private TextBox angleTextBox;
        private Label angleLabel;
        private Button button4;
    }
}
