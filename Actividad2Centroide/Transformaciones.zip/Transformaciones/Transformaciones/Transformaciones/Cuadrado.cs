﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Transformaciones
{
    internal class Cuadrado:Figura
    {
        PointF originalOrigin;
        int sizeSide;
        bool sizedUp = false;

        public Cuadrado(int sideSideSquare, Point origin)
        {
            originalOrigin = origin;
            sizeSide = sideSideSquare;


            generateSquare();
            updateCentroid();
        }

        private void generateSquare() 
        {
            puntos.Add(new PointF(originalOrigin.X, originalOrigin.Y));
            puntos.Add(new PointF(originalOrigin.X, sizeSide));
            puntos.Add(new PointF(sizeSide, sizeSide));
            puntos.Add(new PointF(sizeSide, originalOrigin.Y));
        }

        public void regenerateSquare() 
        {
            puntos[0] = (new PointF(originalOrigin.X, originalOrigin.Y));
            puntos[1] = (new PointF(originalOrigin.X, sizeSide));
            puntos[2] = (new PointF(sizeSide, sizeSide));
            puntos[3] = (new PointF(sizeSide, originalOrigin.Y));
        }

        public void translateFourthCuadrant(Size size) 
        {
            regenerateSquare();
            for (int p = 0; p < puntos.Count; p++)
            {
                puntos[p] = TranslateToCenter(puntos[p], size);
            }
            updateCentroid();
        }

        public void translateSquareCenter(Size size) 
        {
            translateFourthCuadrant(size);
            puntos[0] = Translate(puntos[0], new PointF(-50,-50));
            puntos[1] = Translate(puntos[1], new PointF(-50, -50));
            puntos[2] = Translate(puntos[2], new PointF(-50, -50));
            puntos[3] = Translate(puntos[3], new PointF(-50, -50));
            updateCentroid();
        }

        public void scaleSquare()
        {
            if (sizedUp) 
            {
                puntos[1] = new PointF(puntos[1].X, puntos[1].Y-100);
                puntos[2] = new PointF(puntos[2].X - 100, puntos[2].Y-100);
                puntos[3] = new PointF(puntos[3].X - 100, puntos[3].Y);
                sizeSide = 1;
            }
            else
            {
                puntos[1] = new PointF(puntos[1].X, puntos[1].Y + 100);
                puntos[2] = new PointF(puntos[2].X + 100, puntos[2].Y + 100);
                puntos[3] = new PointF(puntos[3].X + 100, puntos[3].Y);
                sizeSide = 100;
            }
            sizedUp = !sizedUp;
            updateCentroid() ;
        }


        

    }
}
