﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transformaciones
{
    internal class Triangulo : Figura
    {

        PointF originalOrigin;
        int sizeSide;
        bool sizedUp = false;

        public Triangulo(int sideSideSquare, Point origin)
        {
            originalOrigin = origin;
            sizeSide = sideSideSquare;


            generateTriangle();
            updateCentroid();
        }

        private void generateTriangle()
        {
            puntos.Add(new PointF(originalOrigin.X, originalOrigin.Y));
            puntos.Add(new PointF(originalOrigin.X, sizeSide));
            puntos.Add(new PointF((originalOrigin.X + sizeSide), sizeSide));
        }

        public void regenerateTriangle()
        {
            puntos[0] = (new PointF(originalOrigin.X, originalOrigin.Y));
            puntos[1] = (new PointF(originalOrigin.X, sizeSide));
            puntos[2] = (new PointF((originalOrigin.X + sizeSide), sizeSide));
        }

        public void translateFourthCuadrant(Size size)
        {
            regenerateTriangle();
            for (int p = 0; p < puntos.Count; p++)
            {
                puntos[p] = TranslateToCenter(puntos[p], size);
            }
            updateCentroid();
        }

        public void translateTriangleCenter(Size size)
        {
            translateFourthCuadrant(size);
            puntos[0] = Translate(puntos[0], new PointF(-50, -50));
            puntos[1] = Translate(puntos[1], new PointF(-50, -50));
            puntos[2] = Translate(puntos[2], new PointF(-50, -50));
            updateCentroid();
        }

        public void scaleTraingle()
        {
            if (sizedUp)
            {
                puntos[1] = new PointF(puntos[1].X, puntos[1].Y - 100);
                puntos[2] = new PointF(puntos[2].X - 100, puntos[2].Y - 100);
                sizeSide = 1;
            }
            else
            {
                puntos[1] = new PointF(puntos[1].X, puntos[1].Y + 100);
                puntos[2] = new PointF(puntos[2].X + 100, puntos[2].Y + 100);
                sizeSide = 100;
            }
            sizedUp = !sizedUp;
            updateCentroid() ;
        }

    }   
}
