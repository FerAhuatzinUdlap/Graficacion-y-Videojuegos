namespace Transformaciones
{
    public partial class Form1 : Form
    {

        Figura cuadrado;
        Figura triangulo;
        Canvas canvas;
        bool showingSquare;
        bool translate;
        int scale;
        public Form1()
        {
            InitializeComponent();

            canvas = new Canvas(pictureBox1);
            cuadrado = new Figura();
            cuadrado.addPoint(new PointF(0, 0));
            cuadrado.addPoint(new PointF(0, 1));
            cuadrado.addPoint(new PointF(1, 1));
            cuadrado.addPoint(new PointF(1, 0));
            triangulo = new Figura();
            triangulo.addPoint(new PointF(0, 0));
            triangulo.addPoint(new PointF(0, 1));
            triangulo.addPoint(new PointF(1, 1));
            showingSquare = true;
            translate = false;
            scale = 0;
            Render();
        }

        public void Render()
        {

            if (showingSquare)
            {
                canvas.renderFigure(cuadrado, pictureBox1.Size);
            }
            else
            {
                canvas.renderFigure(triangulo, pictureBox1.Size);
            }

            pictureBox1.Refresh();

        }
        private void button3_Click(object sender, EventArgs e)
        {
            translate = !translate;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (scale == 100)
            {
                scale = 0;
            }
            else
            {
                scale = 100;
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            showingSquare = !showingSquare;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            //hacer constantemente las transformaciones al punto original
            cuadrado.scaleFigure(scale);
            triangulo.scaleFigure(scale);


            cuadrado.rotateFigure(angleTextBox.Text);
            triangulo.rotateFigure(angleTextBox.Text);

            if (translate)
            {
                cuadrado.translateFigureCenter(pictureBox1.Size);
                triangulo.translateFigureCenter(pictureBox1.Size);
            }
            else
            {
                cuadrado.translate_0_0();
                triangulo.translate_0_0();
            }

            //renderizar constantemente
            if (showingSquare)
            {
                canvas.renderFigure(cuadrado, pictureBox1.Size);
            }
            else
            {
                canvas.renderFigure(triangulo, pictureBox1.Size);
            }

            pictureBox1.Refresh();
        }

        //explanations of buttons

        private void angleLabel_MouseHover(object sender, EventArgs e)
        {
            label2.Visible = true;
        }

        private void angleLabel_MouseLeave(object sender, EventArgs e)
        {
            label2.Visible = false;
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            label4.Visible = true;
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            label4.Visible = false;
        }

        private void button6_MouseHover(object sender, EventArgs e)
        {
            label3.Visible = true;
        }

        private void button6_MouseLeave(object sender, EventArgs e)
        {
            label3.Visible = false;
        }
    }
}
