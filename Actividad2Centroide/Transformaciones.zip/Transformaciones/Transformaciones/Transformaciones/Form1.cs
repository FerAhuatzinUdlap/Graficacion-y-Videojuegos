namespace Transformaciones
{
    public partial class Form1 : Form
    {

        Cuadrado cuadrado;
        Triangulo triangulo;
        Canvas canvas;
        bool showingSquare;

        public Form1()
        {
            InitializeComponent();

            canvas = new Canvas(pictureBox1);
            cuadrado = new Cuadrado(1, new Point(0, 0));
            triangulo = new Triangulo(1, new Point(0, 0));
            showingSquare = true;
            Render();
        }

        public void Render()
        {
            
            if (showingSquare)
            {
                canvas.RenderSquare(cuadrado, pictureBox1.Size);
            }
            else
            {
                canvas.RenderTriangle(triangulo, pictureBox1.Size);
            }

            pictureBox1.Refresh();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            cuadrado.regenerateSquare();
            triangulo.regenerateTriangle();
            Render();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cuadrado.translateFourthCuadrant(pictureBox1.Size);
            triangulo.translateFourthCuadrant(pictureBox1.Size);
            Render();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cuadrado.translateSquareCenter(pictureBox1.Size);
            triangulo.translateTriangleCenter(pictureBox1.Size);
            Render();
        }

        private void button5_Click(object sender, EventArgs e)
        {

            cuadrado.rotateFigure(angleTextBox.Text);
            triangulo.rotateFigure(angleTextBox.Text);
            Render();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            cuadrado.scaleSquare();
            triangulo.scaleTraingle();
            Render();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            showingSquare = !showingSquare;
            Render();
        }
    }
}
