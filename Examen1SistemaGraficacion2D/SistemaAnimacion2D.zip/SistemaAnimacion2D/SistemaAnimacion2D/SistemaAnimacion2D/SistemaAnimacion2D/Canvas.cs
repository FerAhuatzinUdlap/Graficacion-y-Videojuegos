﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAnimacion2D
{
    internal class Canvas
    {
        Bitmap bmp;
        Graphics g;
        Size size;

        public Canvas(PictureBox pictureBox)
        {
            bmp = new Bitmap(pictureBox.Width, pictureBox.Height);
            g = Graphics.FromImage(bmp);
            pictureBox.Image = bmp;
            size = pictureBox.Size;
        }

        public void renderFigure(Figure figure)
        {
            g.Clear(Color.Black);
            figure.renderFigure(g);

        }

        public void animateFigure(Figure figure, bool firstAnimation)
        {
            if (firstAnimation)
            {
                g.Clear(Color.Black);
            }
            figure.animateFigure(g);

        }
    }
}
