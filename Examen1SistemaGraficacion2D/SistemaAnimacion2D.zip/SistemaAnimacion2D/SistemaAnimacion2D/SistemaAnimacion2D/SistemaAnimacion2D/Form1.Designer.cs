﻿namespace SistemaAnimacion2D
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            renderPictureBox = new PictureBox();
            playButton = new Button();
            timer = new System.Windows.Forms.Timer(components);
            addFigureButton = new Button();
            Lock1Button = new Button();
            Lock2Button = new Button();
            angleTrackBar = new TrackBar();
            scaleTrackBar = new TrackBar();
            XtrackBar = new TrackBar();
            YtrackBar = new TrackBar();
            figuresListBox = new ListBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            warningLabel = new Label();
            addTriangleButton = new Button();
            addTrapezeButton = new Button();
            ((System.ComponentModel.ISupportInitialize)renderPictureBox).BeginInit();
            ((System.ComponentModel.ISupportInitialize)angleTrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)scaleTrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)XtrackBar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)YtrackBar).BeginInit();
            SuspendLayout();
            // 
            // renderPictureBox
            // 
            renderPictureBox.BorderStyle = BorderStyle.FixedSingle;
            renderPictureBox.Location = new Point(226, 110);
            renderPictureBox.Margin = new Padding(3, 2, 3, 2);
            renderPictureBox.Name = "renderPictureBox";
            renderPictureBox.Size = new Size(963, 526);
            renderPictureBox.TabIndex = 0;
            renderPictureBox.TabStop = false;
            // 
            // playButton
            // 
            playButton.BackColor = Color.Red;
            playButton.Cursor = Cursors.Hand;
            playButton.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            playButton.Location = new Point(46, 21);
            playButton.Margin = new Padding(3, 2, 3, 2);
            playButton.Name = "playButton";
            playButton.Size = new Size(82, 22);
            playButton.TabIndex = 3;
            playButton.Text = "Play";
            playButton.UseVisualStyleBackColor = false;
            playButton.Click += playButton_Click;
            // 
            // timer
            // 
            timer.Enabled = true;
            timer.Tick += timer_Tick;
            // 
            // addFigureButton
            // 
            addFigureButton.BackColor = Color.Gray;
            addFigureButton.Cursor = Cursors.Hand;
            addFigureButton.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addFigureButton.Location = new Point(162, 21);
            addFigureButton.Margin = new Padding(3, 2, 3, 2);
            addFigureButton.Name = "addFigureButton";
            addFigureButton.Size = new Size(91, 22);
            addFigureButton.TabIndex = 4;
            addFigureButton.Text = "Add square";
            addFigureButton.UseVisualStyleBackColor = false;
            addFigureButton.Click += addFigureButton_Click;
            // 
            // Lock1Button
            // 
            Lock1Button.BackColor = Color.DarkGray;
            Lock1Button.Cursor = Cursors.Hand;
            Lock1Button.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lock1Button.Location = new Point(576, 21);
            Lock1Button.Margin = new Padding(3, 2, 3, 2);
            Lock1Button.Name = "Lock1Button";
            Lock1Button.Size = new Size(126, 22);
            Lock1Button.TabIndex = 5;
            Lock1Button.Text = "Lock Position 1";
            Lock1Button.UseVisualStyleBackColor = false;
            Lock1Button.Click += Lock1Button_Click;
            // 
            // Lock2Button
            // 
            Lock2Button.BackColor = Color.DarkGray;
            Lock2Button.Cursor = Cursors.Hand;
            Lock2Button.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Lock2Button.Location = new Point(732, 21);
            Lock2Button.Margin = new Padding(3, 2, 3, 2);
            Lock2Button.Name = "Lock2Button";
            Lock2Button.Size = new Size(126, 22);
            Lock2Button.TabIndex = 6;
            Lock2Button.Text = "Lock Position 2";
            Lock2Button.UseVisualStyleBackColor = false;
            Lock2Button.Click += Lock2Button_Click;
            // 
            // angleTrackBar
            // 
            angleTrackBar.Cursor = Cursors.Hand;
            angleTrackBar.Location = new Point(226, 67);
            angleTrackBar.Margin = new Padding(3, 2, 3, 2);
            angleTrackBar.Maximum = 360;
            angleTrackBar.Name = "angleTrackBar";
            angleTrackBar.Size = new Size(962, 45);
            angleTrackBar.TabIndex = 7;
            // 
            // scaleTrackBar
            // 
            scaleTrackBar.Cursor = Cursors.Hand;
            scaleTrackBar.Location = new Point(1216, 110);
            scaleTrackBar.Margin = new Padding(3, 2, 3, 2);
            scaleTrackBar.Maximum = 300;
            scaleTrackBar.Name = "scaleTrackBar";
            scaleTrackBar.Orientation = Orientation.Vertical;
            scaleTrackBar.Size = new Size(45, 525);
            scaleTrackBar.TabIndex = 8;
            // 
            // XtrackBar
            // 
            XtrackBar.Cursor = Cursors.Hand;
            XtrackBar.Location = new Point(207, 646);
            XtrackBar.Maximum = 1360;
            XtrackBar.Name = "XtrackBar";
            XtrackBar.Size = new Size(988, 45);
            XtrackBar.TabIndex = 9;
            XtrackBar.TickStyle = TickStyle.Both;
            // 
            // YtrackBar
            // 
            YtrackBar.Cursor = Cursors.Hand;
            YtrackBar.Location = new Point(157, 100);
            YtrackBar.Margin = new Padding(3, 2, 3, 2);
            YtrackBar.Maximum = 700;
            YtrackBar.Name = "YtrackBar";
            YtrackBar.Orientation = Orientation.Vertical;
            YtrackBar.Size = new Size(45, 525);
            YtrackBar.TabIndex = 10;
            YtrackBar.TickStyle = TickStyle.Both;
            // 
            // figuresListBox
            // 
            figuresListBox.BackColor = Color.Black;
            figuresListBox.Cursor = Cursors.Hand;
            figuresListBox.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            figuresListBox.ForeColor = Color.White;
            figuresListBox.FormattingEnabled = true;
            figuresListBox.ItemHeight = 14;
            figuresListBox.Location = new Point(11, 120);
            figuresListBox.Margin = new Padding(3, 2, 3, 2);
            figuresListBox.Name = "figuresListBox";
            figuresListBox.Size = new Size(132, 480);
            figuresListBox.TabIndex = 11;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(0, 0);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 12;
            label1.Text = "label1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ButtonHighlight;
            label2.Location = new Point(152, 71);
            label2.Margin = new Padding(2, 0, 2, 0);
            label2.Name = "label2";
            label2.Size = new Size(65, 14);
            label2.TabIndex = 13;
            label2.Text = "Rotation";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ButtonHighlight;
            label3.Location = new Point(168, 632);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(14, 14);
            label3.TabIndex = 14;
            label3.Text = "Y";
            label3.Click += label3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ButtonHighlight;
            label4.Location = new Point(196, 656);
            label4.Margin = new Padding(2, 0, 2, 0);
            label4.Name = "label4";
            label4.Size = new Size(14, 14);
            label4.TabIndex = 15;
            label4.Text = "X";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ButtonHighlight;
            label5.Location = new Point(1205, 89);
            label5.Margin = new Padding(2, 0, 2, 0);
            label5.Name = "label5";
            label5.Size = new Size(48, 14);
            label5.TabIndex = 16;
            label5.Text = "Escale";
            // 
            // warningLabel
            // 
            warningLabel.AutoSize = true;
            warningLabel.Font = new Font("Stencil", 10.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            warningLabel.ForeColor = Color.Red;
            warningLabel.Location = new Point(945, 21);
            warningLabel.Margin = new Padding(2, 0, 2, 0);
            warningLabel.Name = "warningLabel";
            warningLabel.Size = new Size(308, 18);
            warningLabel.TabIndex = 17;
            warningLabel.Text = "WARNING: One lock position is missing";
            warningLabel.Visible = false;
            // 
            // addTriangleButton
            // 
            addTriangleButton.BackColor = Color.Gray;
            addTriangleButton.Cursor = Cursors.Hand;
            addTriangleButton.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addTriangleButton.Location = new Point(278, 21);
            addTriangleButton.Margin = new Padding(3, 2, 3, 2);
            addTriangleButton.Name = "addTriangleButton";
            addTriangleButton.Size = new Size(104, 22);
            addTriangleButton.TabIndex = 18;
            addTriangleButton.Text = "Add triangle";
            addTriangleButton.UseVisualStyleBackColor = false;
            addTriangleButton.Click += addTriangleButton_Click_1;
            // 
            // addTrapezeButton
            // 
            addTrapezeButton.BackColor = Color.Gray;
            addTrapezeButton.Cursor = Cursors.Hand;
            addTrapezeButton.Font = new Font("Stencil", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            addTrapezeButton.Location = new Point(406, 21);
            addTrapezeButton.Margin = new Padding(3, 2, 3, 2);
            addTrapezeButton.Name = "addTrapezeButton";
            addTrapezeButton.Size = new Size(91, 22);
            addTrapezeButton.TabIndex = 19;
            addTrapezeButton.Text = "Add trapeze";
            addTrapezeButton.UseVisualStyleBackColor = false;
            addTrapezeButton.Click += addTrapezeButton_Click_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1272, 497);
            Controls.Add(addTrapezeButton);
            Controls.Add(addTriangleButton);
            Controls.Add(warningLabel);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(figuresListBox);
            Controls.Add(YtrackBar);
            Controls.Add(XtrackBar);
            Controls.Add(scaleTrackBar);
            Controls.Add(angleTrackBar);
            Controls.Add(Lock2Button);
            Controls.Add(Lock1Button);
            Controls.Add(addFigureButton);
            Controls.Add(playButton);
            Controls.Add(renderPictureBox);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "AddFigure";
            ((System.ComponentModel.ISupportInitialize)renderPictureBox).EndInit();
            ((System.ComponentModel.ISupportInitialize)angleTrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)scaleTrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)XtrackBar).EndInit();
            ((System.ComponentModel.ISupportInitialize)YtrackBar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox renderPictureBox;
        private Button playButton;
        private System.Windows.Forms.Timer timer;
        private Button addFigureButton;
        private Button Lock1Button;
        private Button Lock2Button;
        private TrackBar angleTrackBar;
        private TrackBar scaleTrackBar;
        private TrackBar XtrackBar;
        private TrackBar YtrackBar;
        private ListBox figuresListBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label warningLabel;
        private Button addTriangleButton;
        private Button addTrapezeButton;
    }
}
