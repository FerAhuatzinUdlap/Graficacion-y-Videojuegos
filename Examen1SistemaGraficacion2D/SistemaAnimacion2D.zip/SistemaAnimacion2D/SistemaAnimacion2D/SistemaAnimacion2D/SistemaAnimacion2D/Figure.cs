﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace SistemaAnimacion2D
{
    internal class Figure
    {
        public PointF centroid;
        public PointF varCentroid;
        //lista de puntos originales que son los que son transformados
        public List<PointF> points;
        //las siguientes listas sirven para que una vez que se haga x transformacion los datos se queden
        //tal cual hasta que se haga una transformacion del mismo tipo
        public List<PointF> scaledPoints;
        public List<PointF> translatedPoints;
        public List<PointF> transformedPoints;
        public List<PointF> lastTransformation;
        public List<PointF> position1;
        public List<PointF> position2;
        public List<PointF> animatedPoints;

        private int translateX;
        private int translateY;

        public Figure()
        {
            points = new List<PointF>();
            scaledPoints = new List<PointF>();
            translatedPoints = new List<PointF>();
            transformedPoints = new List<PointF>();
            lastTransformation = new List<PointF>();
            position1 = new List<PointF>();
            position2 = new List<PointF>();
            animatedPoints = new List<PointF>();
            translateX = -680;
            translateY = 350;
        }

        public void addPoint(PointF point)
        {
            //en esta funcion va a permitir crear cualquier tipo de figura solo indicando los puntos
            //luego se puede escalar a que los puntos provengan de las coordenadas del picture box con un click
            points.Add(point);
            scaledPoints.Add(point);
            translatedPoints.Add(point);
            transformedPoints.Add(point);
            position1.Add(point);
            position2.Add(point);
            animatedPoints.Add(point);
            centroid = getCentroid(points);
        }

        public void renderFigure(Graphics g)
        {
            //une los puntos adyacentes conforme se fueron agregando
            for (int p = 0; p < points.Count - 1; p++)
            {
                g.DrawLine(Pens.Yellow, transformedPoints[p], transformedPoints[p + 1]);
            }
            g.DrawLine(Pens.Yellow, transformedPoints[points.Count - 1], transformedPoints[0]);
        }

        public void animateFigure(Graphics g)
        {
            //une los puntos adyacentes conforme se fueron agregando
            for (int p = 0; p < points.Count - 1; p++)
            {
                g.DrawLine(Pens.Yellow, animatedPoints[p], animatedPoints[p + 1]);
            }
            g.DrawLine(Pens.Yellow, animatedPoints[points.Count - 1], animatedPoints[0]);
        }

        //get centroid based in "current" position of points
        public PointF getCentroid(List<PointF> list)
        {
            //promedio de puntos = centroide
            PointF c = new PointF(0, 0);
            for (int p = 0; p < points.Count; p++)
            {
                c.X += list[p].X;
                c.Y += list[p].Y;
            }
            float x = c.X / points.Count;
            float y = c.Y / points.Count;
            return new PointF(x, y);
        }




        //TRASLACIONES


        public void SetTranslation(int x, int y)
        {
            translateX = x;
            translateY = y;
        }


        private PointF TranslateToCenter(PointF a, Size size)
        {
            int Sx = (int)(size.Width / 2 - 680);
            int Sy = (int)(size.Height / 2 + 350);

            return (new PointF(a.X + Sx, Sy + a.Y));
        }
        //esto dependiendo de cuanto arrastres los vertices va a ser el punto b en el proyecto
        private PointF Translate(PointF a, PointF b)
        {
            return (new PointF(a.X + b.X, a.Y + b.Y));
        }

     

        //TRASLACIONES
        public void translate_0_0()
        {
            for (int p = 0; p < points.Count; p++)
            {
                transformedPoints[p] = translatedPoints[p];
            }
        }

        public void translateFigureFourthQuadrant(Size size)
        {
            for (int p = 0; p < points.Count; p++)
            {
                transformedPoints[p] = TranslateToCenter(translatedPoints[p], size);

                transformedPoints[p] = Translate(transformedPoints[p], new PointF(translateX, -(translateY)));
            }
        }





        //ROTACION
        //rotar con respecto al pivote
        private PointF Rotate(PointF a, double angle, PointF center)
        {
            PointF b = new PointF();

            b.X = (float)((a.X - center.X) * Math.Cos(angle) - (a.Y - center.Y) * Math.Sin(angle) + center.X);
            b.Y = (float)((a.X - center.X) * Math.Sin(angle) + (a.Y - center.Y) * Math.Cos(angle) + center.Y);

            return b;
        }



        //ROTACION
        public void rotateFigure(int angleText)
        {
            try
            {
                double angle = (double)((angleText) * Math.PI / 180);
                for (int p = 0; p < points.Count; p++)
                {
                    translatedPoints[p] = Rotate(scaledPoints[p], angle, varCentroid);
                }
            }
            catch (Exception e)
            {
                double angle = 0;
                for (int p = 0; p < points.Count; p++)
                {
                    translatedPoints[p] = Rotate(scaledPoints[p], angle, varCentroid);
                }
            }
            
        }
        //SCALE
        //using centroid as pivot
        private PointF scalePoint(PointF point, int scaleQuantity)
        {
            float x = point.X;
            float y = point.Y;
            //handle x
            if (x > centroid.X)
            {
                x = x*scaleQuantity;
            } //END IF
            else 
            {
                x =  (x*-scaleQuantity);
            }//END ELSE

            if (y > centroid.Y)
            {
                y =  (y*scaleQuantity);
            } //END IF
            else
            {
                y =  (y*-scaleQuantity);
            }//END ELSE
            return new PointF(x, y);
        }

        //escalar con respecto a las dimensiones deseadas, luego habra que hacer una funcion que lo haga punto por punto
        //dependiendo de cuanto arrastres el punto haces la resta y listo esa es la scale quantity
        public void scaleFigure(int scaleQuantity)
        {
            for (int p = 0; p < points.Count; p++)
            {
                scaledPoints[p] = scalePoint(points[p],scaleQuantity);
                
            }
            varCentroid = getCentroid(scaledPoints);
        }

        public void decideWhichLock(int i)
        {
            if (i == 1)
            {
                lockPosition(position1);
            }
            if (i == 2)
            {
                lockPosition(position2);
            }
        }

        public void lockPosition(List<PointF> toLock)
        {
            for (int i = 0;i<transformedPoints.Count();i++)
            {
                toLock[i] = transformedPoints[i];
            }
        }

        private PointF interpolatePoint(float alpha, PointF A, PointF B)
        {
            float x = (A.X * (1 - alpha)) + B.X * alpha;
            float y = (A.Y * (1 - alpha)) + B.Y * alpha;
            return new PointF(x, y);
        }

        public void interpolateFigure(float alpha)
        {
            for (int i = 0; i<animatedPoints.Count();i++)
            {
                animatedPoints[i] = interpolatePoint(alpha, position1[i], position2[i]);
            }
        }
    }
}
