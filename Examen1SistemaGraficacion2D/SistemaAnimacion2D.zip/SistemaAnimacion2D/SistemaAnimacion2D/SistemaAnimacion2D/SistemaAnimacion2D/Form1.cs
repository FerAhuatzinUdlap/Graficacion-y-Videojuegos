namespace SistemaAnimacion2D
{
    public partial class Form1 : Form
    {
        private List<Figure> figures = new List<Figure>();
        private List<PointF> squareOgPoints = new List<PointF>();
        private List<PointF> triangleOgPoints = new List<PointF>();
        private List<PointF> trapezeOgPoints = new List<PointF>();
        private List<int[]> transformationsInputs = new List<int[]>();
        private List<bool[]> lockeds = new List<bool[]>();
        private Canvas canvas;
        public PointF squareCenter;
        bool play;
        int counter;
        float alpha;
        public Form1()
        {
            InitializeComponent();
            figures = new List<Figure>();
            squareOgPoints = [new PointF(1, 1), new PointF(1, 2), new PointF(2, 2), new PointF(2, 1)];
            triangleOgPoints = [new PointF(1, 1), new PointF(1, 2), new PointF(2,2)];
            //trapezeOgPoints = [new PointF(0, 0), new PointF(0.25f, 1), new PointF(.75f, 1), new PointF(1, 0)];
            trapezeOgPoints = [new PointF(3, 1), new PointF(6, 1), new PointF(8, 5), new PointF(1, 5)];

            canvas = new Canvas(renderPictureBox);
            play = false;
            counter = 0;
            alpha = 0;
            XtrackBar.Value = XtrackBar.Maximum / 2;
            YtrackBar.Value = YtrackBar.Maximum / 2;


        }


        private void addFigureButton_Click(object sender, EventArgs e)
        {
            //create new figure using og points
            figures.Add(new Figure());
            figuresListBox.Items.Add("Figure " + figures.Count());
            lockeds.Add(new bool[] { false, false });
            for (int i = 0; i < squareOgPoints.Count(); i++)
            {
                figures[figures.Count() - 1].addPoint(squareOgPoints[i]);
            }//end for
        }
        private void addTriangleButton_Click_1(object sender, EventArgs e)
        {
            //create new figure using og points
            figures.Add(new Figure());
            figuresListBox.Items.Add("Figure " + figures.Count());
            lockeds.Add(new bool[] { false, false });
            for (int i = 0; i < triangleOgPoints.Count(); i++)
            {
                figures[figures.Count() - 1].addPoint(triangleOgPoints[i]);
            }//end for

        }
        private void addTrapezeButton_Click_1(object sender, EventArgs e)
        {
            //create new figure using og points
            figures.Add(new Figure());
            figuresListBox.Items.Add("Figure " + figures.Count());
            lockeds.Add(new bool[] { false, false });
            for (int i = 0; i < trapezeOgPoints.Count(); i++)
            {
                figures[figures.Count() - 1].addPoint(trapezeOgPoints[i]);
            }//end for
        }

        private void timer_Tick(object sender, EventArgs e)
        {

            for (int i = 0; i < figures.Count(); i++)
            {


                if (!play)

                {

                    if (figuresListBox.SelectedIndex == i)
                    {

                        figures[i].scaleFigure(scaleTrackBar.Value + 20 );
                        figures[i].rotateFigure(angleTrackBar.Value);
                        figures[i].translateFigureFourthQuadrant(renderPictureBox.Size);
                        figures[i].SetTranslation(XtrackBar.Value, YtrackBar.Value);
                        canvas.renderFigure(figures[i]);

                    }

                }
                else
                {
                    interpolate(i);
                }

            }//end for

            renderPictureBox.Invalidate();
        }

        private void interpolate(int i)
        {
            if (counter <= 30)
            {
                bool firstFigure = false;
                if (i == 0)
                {
                    firstFigure = true;
                }

                figures[i].interpolateFigure(alpha);
                canvas.animateFigure(figures[i], firstFigure);
                if (i == figures.Count() - 1)
                {
                    counter++;
                    alpha = alpha + 1.0f / 30.0f;
                }

                //mandar a llamar a que se anime
            }
            else
            {
                alpha = 0;
                counter = 0;
                play = false;
            }
        }

        private void Lock1Button_Click(object sender, EventArgs e)
        {
            try
            {
                figures[figuresListBox.SelectedIndex].decideWhichLock(1);
                lockeds[figuresListBox.SelectedIndex][0] = true;
            }
            catch (Exception ex)
            {
            }
        }

        private void Lock2Button_Click(object sender, EventArgs e)
        {
            try
            {
                figures[figuresListBox.SelectedIndex].decideWhichLock(2);
                lockeds[figuresListBox.SelectedIndex][1] = true;
            }
            catch (Exception ex)
            {
            }
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            bool canAnimate = true;
            List<int[]> positionsNotTrue = new List<int[]>();
            for (int i = 0; i < lockeds.Count(); i++)
            {
                for (int j = 0; j < lockeds[i].Count(); j++)
                {
                    if (lockeds[i][j] == false)
                    {
                        canAnimate = false;
                        positionsNotTrue.Add(new int[] { i, j });
                    }
                }
            }
            if (canAnimate)
            {
                warningLabel.Visible = false;
                play = true;
            }
            else
            {
                warningLabel.Visible = true;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

       
    }
}
